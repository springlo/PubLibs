//
//  UIImageView+MTExt.swift
//
// Copyright (c) 2016-2020年 Mantis Group. All rights reserved.
//

import UIKit

public extension UIApplication {
    /// Run a block in background after app resigns activity
    func runInBackground(_ closure: @escaping () -> Void, expirationHandler: (() -> Void)? = nil) {
        DispatchQueue.main.async {
            let taskID: UIBackgroundTaskIdentifier
            if let expirationHandler = expirationHandler {
                taskID = self.beginBackgroundTask(expirationHandler: expirationHandler)
            } else {
                taskID = self.beginBackgroundTask(expirationHandler: { })
            }
            closure()
            self.endBackgroundTask(taskID)
        }
    }
    
    /// 获取最上面的ViewController (Get the top most view controller from the base view controller; default param is UIWindow's rootViewController)
    static func topViewController(_ base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(presented)
        }
        return base
    }
    
    
    /// 切换APP icon
    ///
    /// - Parameter name: 本地图片名字 ,在你的Info.plist中 CFBundle​Alternate​Icons
    ///
    ///          <key>CFBundleIcons</key>
    ///          <dict>
    ///            <key>CFBundleAlternateIcons</key>
    ///            <dict>
    ///                 <key>Green</key>
    ///                  <dict>
	///     			    <key>CFBundleIconFiles</key>
	///     			    <array>
    ///                        <string>Green</string>
	///     			    </array>
    ///                 </dict>
    ///             </dict>
    ///         </dict>
    static func changeAppIcon(_ name: String?) {
        if #available(iOS 10.3, *) {
            if UIApplication.shared.supportsAlternateIcons {
                UIApplication.shared.setAlternateIconName(name, completionHandler: { (Error) in
                    print(Error?.localizedDescription ?? "No Error")
                })
            }
        }
    }
}

public extension UIApplication {
    
    /// 获取最前方的Window的RootViewController
    static var windowRootController: UIViewController? {
    if #available(iOS 13.0, *) {
      let windowScene = UIApplication.shared
        .connectedScenes
        .filter { $0.activationState == .foregroundActive }
        .first
      
      if let window = windowScene as? UIWindowScene {
        return window.windows.last?.rootViewController
      }
      
      return UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController
    } else {
      return UIApplication.shared.keyWindow?.rootViewController
    }
  }
  
    
    /// 获取指定界面的最前方的ViewController
    /// - Parameter controller: `UITabBarController` or `UINavigationController` or `presentedViewController`
    /// - Returns: UIViewController
    func currentScreen(controller: UIViewController? = windowRootController) -> UIViewController? {
        if let navigationController = controller as? UINavigationController {
            return currentScreen(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return currentScreen(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return currentScreen(controller: presented)
        }
        return controller
    }
}
