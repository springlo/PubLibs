//
//  MTCobwebs.h
//  MTCobwebs
//
//  Created by Luochun
//  Copyright © 2016-2020年 Mantis Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for MTCobwebs.
FOUNDATION_EXPORT double MTCobwebsVersionNumber;

//! Project version string for MTCobwebs.
FOUNDATION_EXPORT const unsigned char MTCobwebsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTCobwebs/PublicHeader.h>


