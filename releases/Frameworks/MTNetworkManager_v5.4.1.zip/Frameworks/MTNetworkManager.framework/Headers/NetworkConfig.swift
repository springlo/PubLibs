//
//  NetworkConfig.swift
//  MTNetworkManager
//
//  Created by Luochun on 2018/5/10.
//  Copyright © 2018年 Mantis Group. All rights reserved.
//

import Foundation

/// 存储认证相关信息
struct IdentityAndTrust {
    var identityRef: SecIdentity
    var trust: SecTrust
    var certArray: AnyObject
}

public typealias JSONDictionary = [String: Any]

/// 存储商户配置及API环境相关信息
public struct MTServiceConfig {
    /// 签约的商户或合作商的ID,由平台分配。
    var partnerID: String
    
    /// 商户开户时分配的访问key, 一般情况是登录获取
    var accessKey: String
    
    /// 商户配置的安全码, 一般情况是登录获取
    var securityKey: String
    
    /// 服务端BaseUrl
    var serviceApiUrl: String
    
    var signType: SignalType = .md5
    
    /// 图片上传地址，音频上传地址
    var imageUploadUrl: String?
    
    /// 视频上传地址
    var videoUploadUrl: String?
    
    /// api请求版本号 默认v5
    public var apiVersion: APIVersion = .v5
    
    /// 公共参数
    ///
    /// 例如：
    /// ```
    /// ["ext": ["terminal": "APP_C"]]
    /// ```
    public var commonParams: JSONDictionary = [:]
    
    /// 服务器API配置  请求服务前必须设置，最好APP打开第一步设置
    ///
    /// - Parameters:
    ///   - partnerID: PartnerID
    ///   - securityKey: 商户配置的安全码
    ///   - serviceApiUrl: 服务器地址
    ///   - signType: 加密方式  默认： MD5
    public init(partnerID: String, securityKey: String, serviceApiUrl: String, signType: SignalType = .md5) {
        self.partnerID = partnerID
        self.accessKey = partnerID
        self.securityKey = securityKey
        self.serviceApiUrl = serviceApiUrl
        self.signType = signType
    }
    
    /// 服务器API配置  请求服务前必须设置，最好APP打开第一步设置
    ///
    /// - Parameters:
    ///   - partnerID: PartnerID
    ///   - securityKey: 商户配置的安全码
    ///   - serviceApiUrl: 服务器地址
    ///   - imageUploadUrl: 图片上传地址，音频上传地址
    ///   - videoUploadUrl: 视频上传地址
    ///   - signType: 加密方式  默认： MD5
    public init(partnerID: String, securityKey: String, serviceApiUrl: String,imageUploadUrl: String, videoUploadUrl: String,  signType: SignalType = .md5) {
        self.accessKey = partnerID
        self.partnerID = partnerID
        self.securityKey = securityKey
        self.serviceApiUrl = serviceApiUrl
        self.signType = signType
        self.imageUploadUrl = imageUploadUrl
        self.videoUploadUrl = videoUploadUrl
    }

    
    /// 更新请求访问码， 一般情况用户登录成功后，替换
    ///
    /// - Parameters:
    ///   - accessKey: 商户开户时分配的访问key, 一般情况是登录获取
    ///   - securityKey: 商户配置的安全码, 一般情况是登录获取
    public mutating func update(_ accessKey: String, securityKey: String) {
        self.accessKey = accessKey
        self.securityKey = securityKey
    }
}

/// API请求版本
public enum APIVersion {
    case v3
    case v5
}

/// 加密方式
public enum SignalType: String {
    case md5 = "MD5"
    case rsa = "RSA"
}
