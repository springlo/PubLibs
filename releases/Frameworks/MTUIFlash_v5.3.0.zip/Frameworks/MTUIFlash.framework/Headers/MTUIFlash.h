//
//  MTUIFlash.h
//  MTUIFlash
//
//  Created by Luochun
//  Copyright © 2016-2020年 Mantis Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for MTUIFlash.
FOUNDATION_EXPORT double MTUIFlashVersionNumber;

//! Project version string for MTUIFlash.
FOUNDATION_EXPORT const unsigned char MTUIFlashVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTUIFlash/PublicHeader.h>


