//
//  Created by Luochun
//  Copyright © 2016-2020年 Mantis Group. All rights reserved.
//

import UIKit

class MTRectangleCheckBox: UIControl {

}
