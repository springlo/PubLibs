//
//  MTNetworkManager.h
//  MTNetworkManager
//
//  Created by Luochun
//  Copyright © 2016-2020年 Mantis Group. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MTNetworkManager.
FOUNDATION_EXPORT double MTNetworkManagerVersionNumber;

//! Project version string for MTNetworkManager.
FOUNDATION_EXPORT const unsigned char MTNetworkManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTNetworkManager/PublicHeader.h>


