//
//  MTNetworkManager.swift
//
// Copyright (c) 2016-2020年 Mantis Group. All rights reserved.

import Foundation
import Alamofire
import UIKit

/// 请求对象     暂停：suspend()   恢复：resume()   取消:cancel()
public typealias MTRequest = Alamofire.Request


public let ApiClient = MTNetworkManager.shared


public extension MTNetworkManager {

    
    /// 加载网络配置信息，
    ///
    /// - Parameter config: 配置信息
    static func load(with config:MTServiceConfig) {
        MTNetworkManager.config = config
    }
}


/// Request manager
public class MTNetworkManager {
    
    /// 配置信息 `MTServiceConfig`
    public static var config: MTServiceConfig?

    public var debugHttpRequest: Bool = true
    public var debugHttpResponse: Bool = true
    public var debugHttpHeader: Bool = false
    
    private static let sharedInstance = MTNetworkManager()
    
    /// 单例访问
    public static var shared: MTNetworkManager {
        return sharedInstance
    }
    
    open var sessionManager: Session = {
        let configuration = URLSessionConfiguration.default
        //configuration.httpAdditionalHeaders = Session.defaultHTTPHeaders
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 60
        
        if  MTNetworkManager.config == nil {
            //assert(API_CONFIG == nil, "\n ERROR: Must to use MTNetworkManager.loadWithServiceConfig(_:) before all opertions!! \n\n")
            assertionFailure("\n -------- ⚡️⚡️⚡️ ERROR: Must to use MTNetworkManager.loadWithServiceConfig(_:) before all opertions!! \n\n")
            //throw NSError(domain: "not load service config", code: -1, userInfo: nil)
        }
        
        return Alamofire.Session(configuration: configuration)
    }()
    
    init() {
        
//        initWithConfig()

//        addSessionHeader(key: "Accept", value: "application/json")
        
        /*trust server cert*/
//        sessionManager.delegate.sessionDidReceiveChallenge = { [weak self] session, challenge in
//            var disposition: URLSession.AuthChallengeDisposition = .performDefaultHandling
//            var credential: URLCredential?
//            
//            if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
//                disposition = URLSession.AuthChallengeDisposition.useCredential
//                credential = URLCredential(trust: challenge.protectionSpace.serverTrust!)
//            } else {
//                if challenge.previousFailureCount > 0 {
//                    disposition = .cancelAuthenticationChallenge
//                } else {
//                    credential = self?.sessionManager.session.configuration.urlCredentialStorage?.defaultCredential(for: challenge.protectionSpace)
//                    
//                    if credential != nil {
//                        disposition = .useCredential
//                    }
//                }
//            }
//            
//            return (disposition, credential)
//        }
    }
    
    /// 发起一个GET请求
    ///
    /// - Parameters:
    ///   - parameters: 请求参数 默认 nil
    ///   - completion:  完成事件
    /// - Returns: MTRequest
    @discardableResult
    public func get(_ parameters: JSONDictionary? = nil, completion: @escaping(Result<JSONDictionary, NetworkError>) -> Void) -> MTRequest {
        let detector = HTTPDataDetector(requestParameter: parameters!)
        let httpParam = detector.detectRequestParameters()
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        return sessionManager.request(MTNetworkManager.config!.serviceApiUrl, method: .get, parameters: httpParam, encoding: URLEncoding.default, headers: nil).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            /* 错误处理 */
            switch response.result {
            case let .failure(error):
                completion(.failure(.other(error,  NetworkErrorHandler.handle(error: error))))
            case let .success(value):
                if let result = detector.verifyResponseSign( value) {
                    if (result["success"] as? String) == "true"  {  //if let code = result["resultCode"] as? String , code == "EXECUTE_SUCCESS"  {
                        completion( .success(result))
                        return
                    }
                    if let resultCode = result["resultCode"] as? String ,let resultDetail = result["resultDetail"] as? String {
                        completion(.failure(.statusCode(resultCode,  resultDetail)))
                    } else if let resultCode = result["resultCode"] as? String , let resultMessage = result["resultMessage"] as? String {
                        completion(.failure(.statusCode(resultCode,  resultMessage)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                    
                } else {
                    completion(.failure(.couldNotParseJSON("")))
                }
            }
        }
        
    }


    
    /// 发起一个POST请求
    ///
    /// - Parameters:
    ///   - parameters: 请求参数 默认 nil
    ///   - verifySign: 是否验签
    ///   - completion: 完成事件
    /// - Returns: MTRequest
    @discardableResult
    public func post(_ parameters: JSONDictionary? = nil, verifySign: Bool = true, completion: @escaping(Result<JSONDictionary, NetworkError>) -> Void) -> MTRequest {
        let detector = HTTPDataDetector(requestParameter: parameters!)
        let (httpParam, sign) = detector.getParamsAndSign()
        
        let headers: HTTPHeaders = [
            "Content-Type": "application/json;charset=UTF-8",   //"application/x-www-form-urlencoded",
            "Accept": "application/json",
            "x-api-accessKey": MTNetworkManager.config!.accessKey,
            "x-api-signType": MTNetworkManager.config!.signType.rawValue,
            "x-api-sign": sign
        ]
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        
        return sessionManager.request(MTNetworkManager.config!.serviceApiUrl, method: .post, parameters: httpParam, encoding: JSONEncoding.default, headers: headers).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
            switch response.result {
            case let .failure(error):   /* 错误处理 */
                completion(.failure(.other(error,  NetworkErrorHandler.handle(error: error))))
            case let .success(value):
                if self.debugHttpResponse {
                    print("\n==============  🕊🕊🕊🕊 \(httpParam["service"]!) Response:\n" + value)
                }
                if self.debugHttpHeader {
                    print("\n============== 🔥🔥🔥🔥 \(response.response!.allHeaderFields)")
                }
                //guard let sign = response.response?.allHeaderFields["x-api-sign"] as? String else {
                guard let sign = response.response?.find(header: "x-api-sign") else {
                    completion(.failure(.noData))
                    return
                }
                let (result, verify) = detector.verifySign(value, with: sign, verifySign: verifySign)
                if  verify {    //验签成功
                    if let success = result["success"] as? Bool , success  {
                        completion( .success(result))
                        return
                    }
                    
                    if let code = result["code"] as? String, let detail = result["detail"] as? String, detail.count > 0 {
                        completion(.failure(.statusCode(code,  detail)))
                    } else if let code = result["code"] as? String, let message = result["message"] as? String {
                        completion(.failure(.statusCode(code,  message)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                } else {
                    completion(.failure(.couldNotParseJSON("数据错误")))
                }
            }
        }
    }

    /// 发起一个POST请求（带响应model）
    ///
    /// - Parameters:
    ///   - midelType: 满足Codable协议的类型
    ///   - parameters: 请求参数 默认 nil
    ///   - verifySign: 是否验签
    ///   - completion: 完成事件(Result)
    /// - Returns: MTRequest
    @discardableResult
    public func post<T: APIModelCodable>(_ modelType: T.Type, parameters: JSONDictionary? = nil, verifySign: Bool = true,
                                           completion: @escaping(Result< T, NetworkError>) -> Void) -> MTRequest {
        let detector = HTTPDataDetector(requestParameter: parameters!)
        let (httpParam, sign) = detector.getParamsAndSign()
        
        let headers: HTTPHeaders = [
            "Content-Type": "application/json;charset=UTF-8",   //"application/x-www-form-urlencoded",
            "Accept": "application/json",
            "x-api-accessKey": MTNetworkManager.config!.accessKey,
            "x-api-signType": MTNetworkManager.config!.signType.rawValue,
            "x-api-sign": sign
        ]
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        return sessionManager.request(MTNetworkManager.config!.serviceApiUrl, method: .post, parameters: httpParam, encoding: JSONEncoding.default, headers: headers).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
            switch response.result {
            case let .failure(error):   /* 错误处理 */
                completion(.failure( .other(error,  NetworkErrorHandler.handle(error: error))) )
            case let .success(value):
                if self.debugHttpResponse {
                    print("\n==============  🕊🕊🕊🕊 \(httpParam["service"]!) Response:\n" + value)
                }
                //guard let sign = response.response?.allHeaderFields["x-api-sign"] as? String else {
                guard let sign = response.response?.find(header: "x-api-sign") else {
                    return completion( .failure(.noData))
                }
                let (result, verify) = detector.verifySign(value, with: sign, verifySign: verifySign)
                if  verify {    //验签成功
                    
                    if let success = result["success"] as? Bool , success {
                        do {
                            let obj = try T.from(json: value)
                            if let v = obj {
                                return completion(.success(v))
                            } else {
                                return completion( .failure(.couldNotDecode("Failed to decode JSON")))
                            }
                        } catch DecodingError.keyNotFound(let key, let context) {
                            return completion( .failure(.couldNotDecode("missing key '\(key.stringValue)' not found\n\(context.debugDescription)")))
                            ///fatalError("Failed to decode \(value) from bundle due to missing key '\(key.stringValue)' not found – \(context.debugDescription)")
                        } catch DecodingError.typeMismatch(let type, let context) {
                            return completion( .failure(.couldNotDecode("type `\(type)` mismatch \n\(context.codingPath) \n– \(context.debugDescription)")))
                            ///fatalError("Failed to decode \(value) from bundle due to type mismatch – \(context.debugDescription)")
                        } catch DecodingError.valueNotFound(let type, let context) {
                            return completion( .failure(.couldNotDecode("missing `\(type)` value – \n\(context.codingPath) \n –\(context.debugDescription)")))
                            ///fatalError("Failed to decode \(value) from bundle due to missing \(type) value – \(context.debugDescription)")
                        } catch DecodingError.dataCorrupted(_) {
                            return completion( .failure(.couldNotDecode("because it appears to be invalid JSON")))
                            ///fatalError("Failed to decode \(value) from bundle because it appears to be invalid JSON")
                        } catch {
                            return completion( .failure(.couldNotDecode("Failed to decode JSON from bundle: \(error.localizedDescription)")))
                            ///fatalError("Failed to decode \(value) from bundle: \(error.localizedDescription)")
                        }
                        
//                        guard let obj = T.from(json: value) else {
//                            return completion( .failure(.noData))
//                        }
//                        return completion(.success(obj))
                    }
                    
                    if let code = result["code"] as? String, let detail = result["detail"] as? String, detail.count > 0 {
                        completion(.failure(.statusCode(code,  detail)))
                    } else if let code = result["code"] as? String, let message = result["message"] as? String {
                        completion(.failure(.statusCode(code,  message)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                } else {
                    completion(.failure(.couldNotParseJSON("数据错误")))
                }
            }
        }
    }
    
    /// 上传音频文件 m4a格式
    ///
    /// - Parameters:
    ///   - data: 二进制数据
    ///   - parameters: 其他参数
    ///   - completion: 完成事件
    ///   - failure: 石板事件
    public func upload(_ data: Data, with parameters:[String: String], completion: @escaping(Result<JSONDictionary, NetworkError>) -> Void) {//-> MTRequest {
        guard let imageUploadUrl = MTNetworkManager.config!.imageUploadUrl else {
            return
        }
        let detector = HTTPDataDetector(requestParameter: parameters)
        let httpParam = detector.detectRequestParameters()
        
        sessionManager.upload(multipartFormData: { (multipartFormData) in
            let filename = Date().toString("yyyyMMddHHmmssSSS") + String.random(length: 10) + ".m4a"
            //let image = UIImage(named: "启动页-吉祥物")
            //multipartFormData.append(UIImagePNGRepresentation(image!)!, withName: "user_image",  fileName: filename, mimeType: "image/png")
            multipartFormData.append(data, withName: "upload", fileName: filename, mimeType: "application/octet-stream")
            for (key, value) in httpParam {
                multipartFormData.append(((value as! String).data(using: .utf8))!, withName: key)
            }
            
        }, to: imageUploadUrl).responseJSON(completionHandler: { (response) in
            switch response.result {
            case .success(let value):
                
                if let result = value as? [String: Any] {
                    print(result)
                    if let success = result["success"] as? Bool , success  {
                        completion( .success(result))
                        return
                    }

                    if let code = result["code"] as? String, let detail = result["detail"] as? String, detail.count > 0 {
                        completion(.failure(.statusCode(code,  detail)))
                    } else if let code = result["code"] as? String, let message = result["message"] as? String {
                        completion(.failure(.statusCode(code,  message)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                } else {
                    completion(.failure(.statusCode("",  "数据错误")))
                }
            case .failure(let error):
                print(error)
                completion(.failure(.couldNotParseJSON("数据错误")))
                //failure( .other(error),  NetworkErrorHandler.handle(error: error))
            }
        })

    }

    /// 上传图片png
    ///
    /// - Parameters:
    ///   - data: 二进制数据
    ///   - parameters: 其他参数
    ///   - completion: 完成事件
    ///   - failure: 失败事件
    public func uploadImage(_ data: Data, with parameters:[String: String] = [:], securityKey: String? = nil, completion:  @escaping(Result<JSONDictionary, NetworkError>) -> Void) {
        guard let imageUploadUrl = MTNetworkManager.config!.imageUploadUrl else {
            return
        }
        var p = parameters
        
        if p["accessKey"] == nil {
            p["accessKey"] = MTNetworkManager.config!.accessKey
        }
        
        let filename = Date().toString("yyyyMMddHHmmssSSS") + String.random(length: 10) + ".png"
        if !p.keys.contains("fileName") {
            p["fileName"] = filename
        }
        p["timestamp"] = Date().toString("yyyy-MM-dd HH:mm:ss")
        //p["timestamp"] = Date().toString("yyyyMMddHHmmss")
        
        var httpParam = HTTPDataDetector.getUploadSign(p, securityKey: securityKey)
        httpParam["service"] = "upload"
        
//        let headers = [
//            "Content-Type": "multipart/mixed"
//        ]
        sessionManager.upload(multipartFormData: { (multipartFormData) in
            
            //let image = UIImage(named: "xxx")
            //multipartFormData.append(UIImagePNGRepresentation(image!)!, withName: "user_image",  fileName: filename, mimeType: "image/png")
            //multipartFormData.append(data, withName: "user_image",  fileName: filename, mimeType: "image/png")
            multipartFormData.append(data, withName: "user_image",  fileName: filename, mimeType: "image/png")

            
        },  to: imageUploadUrl, method: .post).responseJSON(completionHandler: { (response) in
            switch response.result {
            case .success(let value):
                
                if let result = value as? [String: Any] {
                    print(result)
                    if let success = result["success"] as? Bool , success  {
                        completion( .success(result))
                        return
                    }
                   
                    if let code = result["code"] as? String, let detail = result["detail"] as? String, detail.count > 0 {
                        completion(.failure(.statusCode(code,  detail)))
                    } else if let code = result["code"] as? String, let message = result["message"] as? String {
                        completion(.failure(.statusCode(code,  message)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                } else {
                    completion(.failure(.statusCode("",  "数据错误")))
                }
            case .failure(let error):
                print(error)
                completion(.failure(.couldNotParseJSON("数据错误")))
                //failure( .other(error),  NetworkErrorHandler.handle(error: error))
            }
        })
    }

    /// 上传视频
    ///
    /// - Parameters:
    ///   - path: 本地视频地址
    ///   - parameters: 其他参数
    ///   - completion: 完成事件
    ///   - failure: 失败事件
    public func uploadVideo(at path: String, with parameters:[String: Any], completion:@escaping(Result<JSONDictionary, NetworkError>) -> Void) {
        guard let videoUploadUrl = MTNetworkManager.config!.videoUploadUrl else {
            return
        }
        let detector = HTTPDataDetector(requestParameter: parameters)
        let httpParam = detector.detectRequestParameters()
        
        sessionManager.upload(multipartFormData: { (multipartFormData) in
            multipartFormData.append(URL.init(fileURLWithPath: path), withName: "file")
            for (key, value) in httpParam {
                multipartFormData.append(((value as! String).data(using: .utf8))!, withName: key)
            }
            
        }, to: videoUploadUrl).responseJSON(completionHandler: { (response) in
            switch response.result {
            case .success(let value):
                
                if let result = value as? [String: Any] {
                    print(result)
                    if let success = result["success"] as? Bool , success  {
                        completion( .success(result))
                        return
                    }
                    if let code = result["code"] as? String, let detail = result["detail"] as? String, detail.count > 0 {
                        completion(.failure(.statusCode(code,  detail)))
                    } else if let code = result["code"] as? String, let message = result["message"] as? String {
                        completion(.failure(.statusCode(code,  message)))
                    } else {
                        completion(.failure(.statusCode("",  "数据错误")))
                    }
                } else {
                    completion(.failure(.statusCode("",  "数据错误")))
                }
            case .failure(let error):
                print(error)
                completion(.failure(.couldNotParseJSON("数据错误")))
                //failure( .other(error),  NetworkErrorHandler.handle(error: error))
            }
        })

        
    }
    

    
    /// 下载文件
    ///
    /// - Parameters:
    ///   - filePath: 文件存放路径
    ///   - progress: 进度Block
    ///   - completion: 完成事件
    /// - Returns: 当前请求对象
    @discardableResult
    public func download(_ filePath: String, progress: @escaping (_ precent: Double) -> Void, completion: @escaping (_ result: Data?, _ error: String ) -> Void) -> MTRequest {
        
        return sessionManager.download(filePath)
            .downloadProgress { precent in
                progress(precent.fractionCompleted)
                print("Download Progress: \(precent.fractionCompleted)")
            }
            .responseData { response in
                switch response.result {
                case let .failure(error):
                    completion( nil,  NetworkErrorHandler.handle(error: error))
                case .success(let value):
                    completion( value,  "")
                    break
                }

            }
    }

}

