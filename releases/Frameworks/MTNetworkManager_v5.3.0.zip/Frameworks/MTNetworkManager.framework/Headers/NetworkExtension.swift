//
//  NetworkExtension.swift
//
// Copyright (c) 2016-2020年 Mantis Group. All rights reserved.

import Foundation
import Alamofire

extension HTTPURLResponse {

    func find(header: String) -> String? {
        let keyValues = allHeaderFields.map { (String(describing: $0.key).lowercased(), String(describing: $0.value)) }

        if let headerValue = keyValues.filter({ $0.0 == header.lowercased() }).first {
            return headerValue.1
        }
        return nil
    }

}

/// 网络状态
///
/// - unknown: It is unknown whether the network is reachable.
/// - notReachable: The network is not reachable.
/// - ethernetOrWiFi: The network is reachable over the WiFi connection.
/// - wwan: The network is reachable over the WWAN connection.
public enum MTNetworkReachabilityStatus {
    case unknown
    case notReachable
    case ethernetOrWiFi
    case wwan
}

public extension MTNetworkManager {
    
    
    /// 网络状态监听
    ///
    /// - Parameter statusChanged: 状态
    func networkReachability(statusChanged: @escaping (_ status: MTNetworkReachabilityStatus) -> Void)  {
        let reachability = NetworkReachabilityManager.default
        reachability?.startListening(onUpdatePerforming: { (status) in
            print("Network Status Changed: \(status)")
                       switch status {
                       case .unknown:
                           statusChanged( .unknown)
                       case .notReachable:
                           statusChanged(.notReachable)
                       case .reachable(.ethernetOrWiFi):
                           statusChanged( .ethernetOrWiFi)
                       case .reachable(.cellular):
                           statusChanged( .wwan)
                       }
        })

    }
}




/// 数据请求错误原因
///
/// - couldNotParseJSON: 不能解析Json，或者解密失败
/// - noData: 没有返回数据
/// - statusCode: 非成功状态码: 错误码对应code,处理其他业务逻辑
/// - other: 其他错误，包括网络相关错误
public enum Reason: CustomStringConvertible {
    /// 不能解析Json，或者解密失败
    case couldNotParseJSON
    /// 没有返回数据
    case noData
    /// 非成功代码: 错误码
    case statusCode(String)
    /// 其他原因
    case other(Error)
    
    /// 错误描述
    public var description: String {
        switch self {
        case .couldNotParseJSON:
            return "CouldNotParseJSON"
        case .noData:
            return "NoData"
        case .statusCode(let code):
            return code
        case .other(let error):
            return "Other, Error: \(error.localizedDescription)"
        }
    }
}


/// 数据请求错误原因
///
/// - couldNotParseJSON: 不能解析Json，或者解密失败
/// - noData: 没有返回数据
/// - statusCode: 非成功状态码: 错误码对应code,处理其他业务逻辑
/// - other: 其他错误，包括网络相关错误
public enum NetworkError: Error {
    /// 不能解析Json，或者解密失败
    case couldNotParseJSON(String)
    /// 没有返回数据
    case noData
    /// 非成功代码: 错误码
    case statusCode(String, String)
    /// 其他原因
    case other(Error, String)
    
    /// 错误描述
    public var description: String {
        switch self {
        case .couldNotParseJSON(let str):
            return str
        case .noData:
            return "数据错误"
        case let .statusCode(code, str):
            return str + " (\(code))"
        case .other(_, let str):
            return str
        }
    }
}



/// 请求失败处理事件
public typealias FailureHandler = (_ reason: Reason, _ errorMessage: String?) -> Void

let defaultFailureHandler: FailureHandler = { reason, errorMessage in
    print("\n***************************** MTNetWork Failure *****************************")
    print("Reason: \(reason)")
    if let errorMessage = errorMessage {
        print("errorMessage: >>>\(errorMessage)<<<\n")
    }
}

extension MTNetworkManager {

    func initWithConfig() {
        
//        addSessionHeader(key: "Accept", value: "application/json")
        
//        sessionManager.delegate.sessionDidReceiveChallenge = { session, challenge in
//            //认证服务器证书
//            if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
//
//                let serverTrust:SecTrust = challenge.protectionSpace.serverTrust!
//                let certificate = SecTrustGetCertificateAtIndex(serverTrust, 0)!
//                let remoteCertificateData = CFBridgingRetain(SecCertificateCopyData(certificate))!
//                let cerPath = Bundle.main.path(forResource: "server", ofType: "cer")!
//                let localCertificateData = NSData(contentsOfFile:cerPath)!
//
//                if remoteCertificateData.isEqual(localCertificateData as Data) {
//                    let credential = URLCredential(trust: serverTrust)
//                    challenge.sender?.use(credential, for: challenge)
//                    return (URLSession.AuthChallengeDisposition.useCredential,URLCredential(trust: challenge.protectionSpace.serverTrust!))
//
//                } else {
//                    return (.cancelAuthenticationChallenge, nil)
//                }
//            }
                //认证客户端证书
//            else if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodClientCertificate {
//                //获取客户端证书相关信息
//                let identityAndTrust:IdentityAndTrust = self.extractIdentity()
//                
//                let urlCredential:NSURLCredential = NSURLCredential(identity: identityAndTrust.identityRef, certificates: identityAndTrust.certArray as? [AnyObject], persistence: NSURLCredentialPersistence.ForSession)
//                
//                return (.UseCredential, urlCredential)
//            }
//                // 其它情况（不接受认证）
//            else {
//                print("其它情况（不接受认证）")
//                return (.cancelAuthenticationChallenge, nil)
//            }
//        }
    }
    
    //获取客户端证书相关信息
    func extractIdentity() -> IdentityAndTrust {
        var identityAndTrust:IdentityAndTrust!
        var securityError:OSStatus = errSecSuccess
        
        let path: String = Bundle.main.path(forResource: "mykey", ofType: "p12")!
        let PKCS12Data = NSData(contentsOfFile:path)!
        let key : NSString = kSecImportExportPassphrase as NSString
        let options : NSDictionary = [key : "123456"] //客户端证书密码
        //create variable for holding security information
        //var privateKeyRef: SecKeyRef? = nil
        
        var items : CFArray?
        
        securityError = SecPKCS12Import(PKCS12Data, options, &items)
        
        if securityError == errSecSuccess {
            let certItems:CFArray = (items as CFArray?)!
            let certItemsArray:Array = certItems as Array
            let dict:AnyObject? = certItemsArray.first
            if let certEntry:Dictionary = dict as? Dictionary<String, AnyObject> {
                // grab the identity
                let identityPointer:AnyObject? = certEntry["identity"]
                let secIdentityRef:SecIdentity = (identityPointer as! SecIdentity?)!
                print("\(String(describing: identityPointer))  :::: \(secIdentityRef)")
                // grab the trust
                let trustPointer:AnyObject? = certEntry["trust"]
                let trustRef:SecTrust = trustPointer as! SecTrust
                print("\(String(describing: trustPointer))  :::: \(trustRef)")
                // grab the cert
                let chainPointer:AnyObject? = certEntry["chain"]
                identityAndTrust = IdentityAndTrust(identityRef: secIdentityRef,
                    trust: trustRef, certArray:  chainPointer!)
            }
        }
        return identityAndTrust
    }
    
//    func addSessionHeader(key: String, value: String) {
//
//        let config = sessionManager.session.configuration
//        if var headers = config.httpAdditionalHeaders {
//            headers[key] = value
//            sessionManager = SessionManager(configuration: config)
//        }
//
//    }
//
//
//     /// 移除Session Header
//    public func removeSessionHeaderIfExists(key: String) {
//        let config = sessionManager.session.configuration
//        if var headers = config.httpAdditionalHeaders {
//            headers.removeValue(forKey: key)
//            sessionManager = SessionManager(configuration: config)
//        }
//    }


}
